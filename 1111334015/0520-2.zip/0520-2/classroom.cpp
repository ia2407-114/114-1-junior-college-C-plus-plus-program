#include "classroom.h"

//================ student =================

student::student(int i, string n)
{
    id = i;
    name = n;
}


//================ teacher =================

teacher::teacher(int i, string n)
{
    id = i;
    name = n;
}

void teacher::data_input()
{
    cout << "�п�J�ҵ{�s��:";
    cin >> course_id;

    cin.ignore();

    cout << "�п�J�ҵ{�W��:";
    getline(cin, course_name);

    cout << "�п�J�Ǥ�:";
    cin >> course_credit;
}


//================ classroom =================

classroom::classroom(
    int tid, string tname,
    int sid, string sname
)
    :teacher(tid, tname),
    student(sid, sname)
{
}

void classroom::show()
{
    cout << "\n�ҵ{���" << endl;

    cout << "�ҵ{�s��: "
        << course_id << endl;

    cout << "�ҵ{�W��: "
        << course_name << endl;

    cout << "�Ǥ�: "
        << course_credit << endl;

    cout << "�Юv�m�W: "
        << teacher::name << endl;

    cout << "�ǥͩm�W: "
        << student::name << endl;
}