#ifndef CLASSROOM_H
#define CLASSROOM_H

#include<iostream>
#include<string>
using namespace std;


//================ student =================

class student
{
protected:
    int id;
    string name;

public:
    student(int, string);
};


//================ teacher =================

class teacher
{
protected:
    int id;
    string name;

    string course_id;
    string course_name;
    int course_credit;

public:
    teacher(int, string);

    void data_input();
};


//================ classroom =================

class classroom : public teacher, public student
{
public:
    classroom(int tid, string tname,
        int sid, string sname);

    void show();
};

#endif#pragma once
