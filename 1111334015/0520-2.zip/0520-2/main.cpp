#include<iostream>
#include"classroom.h"
using namespace std;

int main()
{
    int tid, sid;
    string tname, sname;

    cout << "��J�Юv�s��:";
    cin >> tid;

    cin.ignore();

    cout << "��J�Юv�m�W:";
    getline(cin, tname);

    cout << "��J�ǥͽs��:";
    cin >> sid;

    cin.ignore();

    cout << "��J�ǥͩm�W:";
    getline(cin, sname);

    classroom c(
        tid, tname,
        sid, sname
    );

    c.data_input();

    c.show();

    return 0;
}