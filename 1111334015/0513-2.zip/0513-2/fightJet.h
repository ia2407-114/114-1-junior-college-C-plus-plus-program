#ifndef FIGHTJET_H
#define FIGHTJET_H

#include "aircraft.h"

class fightJet : public aircraft
{
private:
    int missileCount;
    double machSpeed;

public:
    fightJet(double ws, double cl, string n, int i,
        int mc, double ms);

    ~fightJet();

    void printFightJet();
};

#endif#pragma once
