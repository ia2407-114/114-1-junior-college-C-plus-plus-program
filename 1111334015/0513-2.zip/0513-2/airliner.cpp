#include "airliner.h"

airliner::airliner(double ws, double cl, string n, int i,
    int pc, int tc)
    : aircraft(ws, cl, n, i)
{
    passengerCount = pc;
    toiletCount = tc;

    cout << "Airliner constructor called!" << endl;
}

airliner::~airliner()
{
    cout << "Airliner destructor called!" << endl;
}

void airliner::printAirliner()
{
    printAircraft();

    cout << "Passenger Count: " << passengerCount << endl;
    cout << "Toilet Count: " << toiletCount << endl;
}