#ifndef AIRLINER_H
#define AIRLINER_H

#include "aircraft.h"

class airliner : public aircraft
{
private:
    int passengerCount;
    int toiletCount;

public:
    airliner(double ws, double cl, string n, int i,
        int pc, int tc);

    ~airliner();

    void printAirliner();
};

#endif#pragma once
