#include "fightJet.h"

fightJet::fightJet(double ws, double cl, string n, int i,
    int mc, double ms)
    : aircraft(ws, cl, n, i)
{
    missileCount = mc;
    machSpeed = ms;

    cout << "FightJet constructor called!" << endl;
}

fightJet::~fightJet()
{
    cout << "FightJet destructor called!" << endl;
}

void fightJet::printFightJet()
{
    printAircraft();

    cout << "Missile Count: " << missileCount << endl;
    cout << "Mach Speed: " << machSpeed << endl;
}