#include <iostream>
#include "airliner.h"
#include "fightJet.h"

using namespace std;

int main()
{
    airliner a1(60.5, 41000, "Boeing 747", 1001,
        416, 10);

    cout << endl;

    a1.printAirliner();

    cout << endl << endl;

    fightJet f1(13.5, 65000, "F-22 Raptor", 2001,
        6, 2.25);

    cout << endl;

    f1.printFightJet();

    cout << endl;

    return 0;
}