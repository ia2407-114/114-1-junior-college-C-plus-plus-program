#include "aircraft.h"

aircraft::aircraft(double ws, double cl, string n, int i)
{
    wingspan = ws;
    ceiling = cl;
    name = n;
    id = i;

    cout << "Aircraft constructor called!" << endl;
}

aircraft::~aircraft()
{
    cout << "Aircraft destructor called!" << endl;
}

void aircraft::printAircraft()
{
    cout << "===== Aircraft Data =====" << endl;
    cout << "Name: " << name << endl;
    cout << "ID: " << id << endl;
    cout << "Wingspan: " << wingspan << " meters" << endl;
    cout << "Ceiling: " << ceiling << " feet" << endl;
}