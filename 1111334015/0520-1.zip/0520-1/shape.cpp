#include "shape.h"

//================ shape =================

shape::shape(string n)
{
    name = n;
    shape_area = 0;
}

void shape::area()
{
    cout << "Area = " << shape_area << endl;
}


//================ rectangle =================

rectangle::rectangle() :shape("Rectangle")
{
    length = 0;
    width = 0;
}

void rectangle::data_input()
{
    cout << "�п�J��:";
    cin >> length;

    cout << "�п�J�e:";
    cin >> width;

    shape_area = length * width;
}


//================ cube =================

cube::cube() :rectangle()
{
    height = 0;
    volume = 0;
}

void cube::data_input()
{
    rectangle::data_input();

    cout << "�п�J��:";
    cin >> height;

    volume = length * width * height;
}

void cube::show()
{
    cout << "��������n = " << volume << endl;
}