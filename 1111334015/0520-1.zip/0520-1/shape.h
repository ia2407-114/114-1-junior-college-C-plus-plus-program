#ifndef SHAPE_H
#define SHAPE_H

#include<iostream>
#include<string>
using namespace std;

class shape
{
protected:
    string name;
    float shape_area;

public:
    shape(string n = "Shape");
    void area();
};

//--------------------------

class rectangle : public shape
{
protected:
    float length;
    float width;

public:
    rectangle();
    void data_input();
};

//--------------------------

class cube : public rectangle
{
private:
    float height;
    float volume;

public:
    cube();
    void data_input();   //��J���רíp����n
    void show();
};

#endif