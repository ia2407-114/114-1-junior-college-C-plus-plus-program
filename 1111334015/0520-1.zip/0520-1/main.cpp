#include<iostream>
#include"shape.h"
using namespace std;

int main()
{
    cube c;

    c.data_input();

    c.show();

    return 0;
}