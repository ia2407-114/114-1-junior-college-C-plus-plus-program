#ifndef ANIMALFILE_H
#define ANIMALFILE_H

#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
using namespace std;

class AnimalFile
{
private:
    ofstream writefile;

public:
    AnimalFile();
    ~AnimalFile();

    void openFile();
    void inputData();
    void closeFile();
};

#endif