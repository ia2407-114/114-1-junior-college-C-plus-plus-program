#include "AnimalFile.h"

int main()
{
    AnimalFile animal;

    animal.openFile();
    animal.inputData();
    animal.closeFile();

    return 0;
}