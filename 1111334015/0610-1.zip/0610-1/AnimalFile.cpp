#include "AnimalFile.h"
#include <cstdlib>

AnimalFile::AnimalFile()
{
}

AnimalFile::~AnimalFile()
{
}

void AnimalFile::openFile()
{
    writefile.open("animal.txt", ios_base::out);

    if (writefile.fail())
    {
        cout << "animal.txt�ɮ׵L�k�}��!\n";
        exit(1);
    }

    // �榡�ƿ�X���D
    writefile << left
        << setw(15) << "�ʪ�"
        << setw(10) << "�~��"
        << setw(10) << "����"
        << endl;
}

void AnimalFile::inputData()
{
    string name;
    int age, height;

    for (int i = 1; i <= 3; i++)
    {
        cout << "��J��" << i
            << "�ذʪ��W�١A�~�֤Ψ���(�H�ť���@�Ϲj):\n";

        cin >> name >> age >> height;

        // �榡�ƿ�X���
        writefile << left
            << setw(15) << name
            << setw(10) << age
            << setw(10) << height
            << endl;

        if (writefile.fail())
        {
            cout << "�g�J����\n";
            break;
        }
    }
}

void AnimalFile::closeFile()
{
    writefile.close();

    if (writefile.fail())
    {
        cout << "animal.txt�ɮ׵L�k����!\n";
        exit(1);
    }
}