#ifndef ANIMALFILE_H
#define ANIMALFILE_H

#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
using namespace std;

class AnimalFile
{
public:
    void writeData();
    void calculateAverage();
    void displayFile();
};

#endif#pragma once
