#include "AnimalFile.h"
#include <cstdlib>

void AnimalFile::writeData()
{
    ofstream writefile;

    writefile.open("animal.txt", ios::out);

    if (writefile.fail())
    {
        cout << "animal.txt�ɮ׵L�k�}��!\n";
        exit(1);
    }

    writefile << left
        << setw(15) << "�ʪ�"
        << setw(10) << "�~��"
        << setw(10) << "����"
        << endl;

    string name;
    int age, height;

    for (int i = 1; i <= 3; i++)
    {
        cout << "��J��" << i
            << "�ذʪ��W�١A�~�֤Ψ���(�H�ť���@�Ϲj): ";

        cin >> name >> age >> height;

        writefile << left
            << setw(15) << name
            << setw(10) << age
            << setw(10) << height
            << endl;
    }

    writefile.close();
}

void AnimalFile::calculateAverage()
{
    fstream file;

    file.open("animal.txt", ios::in | ios::out);

    if (file.fail())
    {
        cout << "animal.txt�ɮ׵L�k�}��!\n";
        exit(1);
    }

    string title;
    getline(file, title);

    string name;
    int age, height;

    float total_age = 0;
    float total_height = 0;

    for (int i = 1; i <= 3; i++)
    {
        file >> name >> age >> height;

        total_age += age;
        total_height += height;
    }

    float avg_age = total_age / 3;
    float avg_height = total_height / 3;

    file.clear();
    file.seekp(0, ios::end);

    file << endl;

    file << fixed << setprecision(1);

    file << "�����~��: "
        << avg_age
        << "\t��������: "
        << avg_height
        << endl;

    file.close();
}

void AnimalFile::displayFile()
{
    ifstream readfile;

    readfile.open("animal.txt");

    if (readfile.fail())
    {
        cout << "animal.txt�ɮ׵L�k�}��!\n";
        exit(1);
    }

    string line;

    cout << "\n===== animal.txt���e =====\n";

    while (getline(readfile, line))
    {
        cout << line << endl;
    }

    readfile.close();
}