#include <iostream>
#include <fstream>
#include "cinema.h"

using namespace std;


int main()
{
    Cinema movie;


    //========================
    // �g�J�q�v���
    //========================

    ofstream writefile;

    writefile.open("movie.bin",
        ios::out | ios::binary);


    if (writefile.fail())
    {
        cout << "movie.bin�ɮ׵L�k�}��!" << endl;
        return 1;
    }


    cout << "�إ߹q�v��T:" << endl;


    for (int i = 0; i < 5; i++)
    {
        cout << "\n��" << i + 1 << "�����" << endl;

        movie.input();


        writefile.write(
            (char*)&movie,
            sizeof(movie)
        );
    }


    writefile.close();



    //========================
    // Ū���q�v���
    //========================


    ifstream readfile;


    readfile.open("movie.bin",
        ios::in | ios::binary);


    if (readfile.fail())
    {
        cout << "movie.bin�ɮ׵L�k�}��!" << endl;
        return 1;
    }



    cout << "\n�q�v�C��:" << endl;


    int i = 1;


    while (readfile.read(
        (char*)&movie,
        sizeof(movie)))
    {

        movie.displayName(i);

        i++;

    }



    //�M��EOF���A

    readfile.clear();



    //========================
    // �d�߫��w���
    //========================


    int no;


    cout << "\n��J�n�ݪ��q�v��ƽs��:";

    cin >> no;



    //�����ɮצ�m

    readfile.seekg(
        sizeof(movie) * (no - 1),
        ios::beg
    );



    readfile.read(
        (char*)&movie,
        sizeof(movie)
    );



    if (!readfile.eof())
    {
        cout << "\n�q�v������:" << endl;

        movie.display();

    }

    else
    {
        cout << "�d�L���" << endl;
    }



    readfile.close();


    return 0;

}