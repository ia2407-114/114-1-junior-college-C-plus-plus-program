#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include "FileManager.h"

using namespace std;

void FileManager::writeFile()
{
    ofstream writefile;

    writefile.open("test.txt", ios_base::out);

    if (writefile.fail())
    {
        cout << "test.txt�ɮ׵L�k�}�ҡI\n";
        exit(1);
    }

    string data;

    cout << "�п�J��ơG";
    getline(cin, data);

    writefile << data << '\n';

    if (writefile.fail())
    {
        cout << "�g�J���ѡI\n";
        exit(1);
    }

    writefile.close();
}

void FileManager::readFile()
{
    ifstream readfile;

    readfile.open("test.txt", ios_base::in);

    if (readfile.fail())
    {
        cout << "test.txt�ɮ׵L�k�}�ҡI\n";
        exit(1);
    }

    char ch;
    int filespace = 0;

    cout << "\n�ɮפ��e�p�U�G\n";

    while (1)
    {
        ch = readfile.get();

        if (readfile.eof())
            break;

        cout << ch;
        filespace++;
    }

    cout << "\n\n�ɮת��׬��G"
        << filespace
        << " �Ӧ줸��(Byte)\n";

    readfile.close();
}