#include "FileManager.h"

int main()
{
    FileManager file;

    file.writeFile();
    file.readFile();

    return 0;
}