#ifndef FILEMANAGER_H
#define FILEMANAGER_H

#include <string>
using namespace std;

class FileManager
{
public:
    void writeFile();
    void readFile();
};

#endif#pragma once
