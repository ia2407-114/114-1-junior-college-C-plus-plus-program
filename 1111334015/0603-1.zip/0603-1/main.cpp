#include "flight_object.h"

int main()
{
    flight_object* flight1;

    airliner air1;

    air1.create_flight_object("�j���Ⱦ�");
    air1.create_airliner();

    flight1 = &air1;
    flight1->display();

    bombplane bomb1;

    bomb1.create_flight_object("�F����");
    bomb1.create_bombplane();

    flight1 = &bomb1;
    flight1->display();

    return 0;
}