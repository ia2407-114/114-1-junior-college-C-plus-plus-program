// Fig. 10.7: Time.cpp
// Time class member- and friend-function definitions.

#include <iostream>
#include <stdexcept>
#include "Time.h"

using namespace std;

// Time constructor
Time::Time(int h, int m, int s)
{
    setTime(h, m, s);
}

// set hour, minute and second
void Time::setTime(int hh, int mm, int ss)
{
    if (hh >= 0 && hh <= 23)
        hour = hh;
    else
        throw invalid_argument("Hour must be 0-23");

    if (mm >= 0 && mm <= 59)
        minute = mm;
    else
        throw invalid_argument("Minute must be 0-59");

    if (ss >= 0 && ss <= 59)
        second = ss;
    else
        throw invalid_argument("Second must be 0-59");
}

// overloaded prefix increment operator
Time& Time::operator++()
{
    helpIncrement();
    return *this;
}

// overloaded postfix increment operator
Time Time::operator++(int)
{
    Time temp = *this;

    helpIncrement();

    return temp;
}

// add specified number of seconds to time
Time& Time::operator+=(unsigned int additionalSeconds)
{
    for (int i = 0; i < additionalSeconds; ++i)
        helpIncrement();

    return *this;
}

// function to help increment the time
void Time::helpIncrement()
{
    ++second;

    if (second >= 60)
    {
        second = 0;
        ++minute;
    }

    if (minute >= 60)
    {
        minute = 0;
        ++hour;
    }

    if (hour >= 24)
    {
        hour = 0;
    }
}

// overloaded output operator
ostream& operator<<(ostream& output, const Time& t)
{
    output << t.hour << ":" << t.minute << ":" << t.second;

    return output;
}