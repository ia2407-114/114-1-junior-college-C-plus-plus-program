#ifndef ANIMALFILE_H
#define ANIMALFILE_H

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
using namespace std;

struct Animal
{
    char name[30];
    int age;
    int height;
};

class AnimalFile
{
public:
    void writeBinaryFile();
    void calculateAverage();
    void displayFile();
};

#endif#pragma once
