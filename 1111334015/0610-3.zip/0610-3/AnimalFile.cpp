#include "AnimalFile.h"

void AnimalFile::writeBinaryFile()
{
    ofstream file("animal.dat", ios::binary);

    if (!file)
    {
        cout << "�ɮ׶}�ҥ��ѡI\n";
        return;
    }

    Animal a;
    char choice;

    do
    {
        cout << "\n�п�J�ʪ��W�١G";
        cin >> a.name;

        cout << "�п�J�~�֡G";
        cin >> a.age;

        cout << "�п�J�����G";
        cin >> a.height;

        file.write((char*)&a, sizeof(a));

        cout << "�O�_�~���J(Y/N)? ";
        cin >> choice;

    } while (choice == 'Y' || choice == 'y');

    file.close();
}