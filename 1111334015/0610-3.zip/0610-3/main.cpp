#include "AnimalFile.h"

int main()
{
    AnimalFile animal;

    animal.writeBinaryFile();

    animal.calculateAverage();

    animal.displayFile();

    return 0;
}